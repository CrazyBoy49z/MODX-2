<?php
require_once (dirname(dirname(__FILE__)) . '/slotmachineitem.class.php');
class SlotmachineItem_mysql extends SlotmachineItem {}