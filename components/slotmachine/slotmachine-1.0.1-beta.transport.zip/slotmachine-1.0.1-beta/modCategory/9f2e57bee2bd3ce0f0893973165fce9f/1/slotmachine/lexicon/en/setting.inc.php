<?php

$_lang['area_slotmachine_main'] = 'Main';

$_lang['setting_slotmachine_some_setting'] = 'Some setting';
$_lang['setting_slotmachine_some_setting_desc'] = 'This is description for some setting';