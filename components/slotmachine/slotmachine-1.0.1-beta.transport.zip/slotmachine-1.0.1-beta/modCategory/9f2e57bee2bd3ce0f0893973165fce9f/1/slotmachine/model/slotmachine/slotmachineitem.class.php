<?php

/**
 * @package slotmachine
 */
class SlotmachineItem extends xPDOSimpleObject
{
}