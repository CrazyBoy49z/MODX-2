Ext.onReady(function () {
    Slotmachine.config.connector_url = OfficeConfig.actionUrl;

    var grid = new Slotmachine.panel.Home();
    grid.render('office-slotmachine-wrapper');

    var preloader = document.getElementById('office-preloader');
    if (preloader) {
        preloader.parentNode.removeChild(preloader);
    }
});